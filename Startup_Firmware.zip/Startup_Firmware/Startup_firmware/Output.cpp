/*
   Class to output pulses with clock division
   Should be triggered every 24ppq
   Tom Whitwell, Music Thing Modular, November 2018
   Herne Hill, London

*/

#include "Arduino.h"
#include "Output.h"
#include <EEPROM.h>

// Variables for Clock & Division
// 0= even 1 = odd
static const int modeCount = 2;
static const int modeEntries = 10;
static const int divideValues[modeCount][modeEntries] = {
  {12,24,48,96,192,384,768,1536,3072,6144},
  //  {4, 8, 16, 24, 36, 72,  144, 288, 576, 1152},// standard
  {16,32,64,96,144,288,84,90,94,95},
  //experimental = five odd - 1/6, 1/3, 2/3, 1, 3/2, then five phase patterns that sync every 4,6,8,12,24 steps
};

Output::Output(int pin, int mode, int dividor) {
  pinMode(pin, OUTPUT);
  _pin = pin;
  _mode = mode;
  _dividor = dividor;
  _div = divideValues[_mode][_dividor];
}

boolean Output::DividorDown() {
  boolean result = true;
  _dividor ++;
  if (_dividor > modeEntries - 1) {
    _dividor = (modeEntries - 1);
    result = false;
  }
  return result;
}

boolean Output::DividorUp() {
  boolean result = true;
  _dividor --;
  if (_dividor < 0) {
    _dividor = 0;
    result = false;
  }
  return result;
}

void Output::Reset() {
  _position = 0;
}

void Output::ModeChange() {
  _mode++;
  if (_mode >= modeCount) _mode = 0;
  digitalWrite(2, _mode);

}

int Output::ModeReport() {
  return _mode;
}

void Output::Update() {
  if (_position == 0) {
    digitalWrite(_pin, HIGH);
    _pulseStart = millis();
    _pulseOn = true;
  }
  if (_pulseOn == true && (millis() - _pulseStart > 10)) { // Length of each output pulse
    digitalWrite(_pin, LOW);
  }
  _position++;
  _div = divideValues[_mode][_dividor];
  if (_position >= _div ) {
    _position = 0;
  }
}

int Output::Position() {
  return _position;
}

void Output::Save(int modeLocation, int divideLocation) {
  EEPROM.update(modeLocation, _mode);
  EEPROM.update(divideLocation, _dividor);
}

void Output::Settings(int mode, int dividor) {
  _mode = mode;
  _dividor = dividor;
}
