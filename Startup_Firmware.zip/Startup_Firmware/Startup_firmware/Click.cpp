/*
   Class to attach functions to short and long pushes on a button
   Tom Whitwell, Music Thing Modular, November 2018 
   Herne Hill, London
*/

#include "Arduino.h"
#include "Click.h"


Click::Click(int pin, void (*functionShort)(), void (*functionLong)() ) {
   pinMode(pin, INPUT_PULLUP);
  _pin = pin;
  _functionShort = functionShort;
  _functionLong = functionLong;
}

void Click::Update() {
  // first time we notice button is pushed
  if (digitalRead(_pin) == LOW &&
      _buttonDown == false) {
    _downTime = millis();
    _buttonDown = true;
    _longPushed = false;
  }

  // while holding, do nothing unless enough time has passed to register a long push
  if (digitalRead(_pin) == LOW &&
           _buttonDown == true &&
           _longPushed == false &&
           (millis() - _downTime) > _tooLong) {
    _longPushed = true;
    _functionLong();
  }

  // button is released checks if bounce, or short push
  if (digitalRead(_pin) == HIGH &&
           _buttonDown == true) {
    _buttonDown = false;
    _pushLength = millis() - _downTime;
    if (_pushLength > _tooShort &&
        _pushLength < _tooLong &&
        _longPushed == false) {
      _functionShort();
    }
  }

}
