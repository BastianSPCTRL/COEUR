/*
   Class to attach functions to short and long pushes on a button
   Tom Whitwell, Music Thing Modular, November 2018 
   Herne Hill, London

*/



#ifndef Click_h
#define Click_h


class Click

{
  public:
    Click(int pin, void (*functionShort)(), void (*functionLong)() );
    void Update();

  private:
    int _pin;
    unsigned long _downTime = 0;
    boolean _buttonDown = false;
    boolean _longPushed = false;
    unsigned long _tooShort = 15; // debounce time; clicks shorter than this are ignored
    unsigned long _tooLong = 500; // minimum time to hold the button and register a hold 
    unsigned long _pushLength; 
    void (*_functionShort)();
    void (*_functionLong)();
};



#endif
