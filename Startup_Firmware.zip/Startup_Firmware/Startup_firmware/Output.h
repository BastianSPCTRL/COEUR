/*
   Class to output pulses with clock division
   Should be triggered every 24ppq
   Tom Whitwell, Music Thing Modular, November 2018
   Herne Hill, London

*/


#ifndef Output_h
#define Output_h

class Output

{
  public:
    Output(int pin, int mode, int dividor);
    boolean DividorUp();
    boolean DividorDown();
    void ModeChange();
    void Update();
    void Reset();
    int Position();
    int ModeReport();
    void Save(int modeLocation, int divideLocation);
    void Settings(int mode, int dividor);

  private:
    int _position = 0;
    int _pin;
    int _mode;
    int _dividor; // dividor index
    int _div = 12; // actual dividor
    unsigned long _pulseStart;
    boolean _pulseOn;
};

#endif
